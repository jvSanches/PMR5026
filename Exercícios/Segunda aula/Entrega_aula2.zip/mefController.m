clear
close all
run loader.m
run plotter.m
run preProcessor.m
run solver.m
run plotter.m
